<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header border-bottom">
                <div class="card-title font-weight-bold">Data Mahasiswa</div>
            </div>
            <div class="card-body pt-3">
                <div class="row">
                    <div class="col col-md-3">NRP</div>
                    <div class="col col-md-9">: 160422071</div>
                    <div class="col col-md-3">Nama</div>
                    <div class="col col-md-9">: KRESNAYANA NANDA ARIFINK</div>
                    <div class="col col-md-3">Angkatan</div>
                    <div class="col col-md-9">: 2022</div>
                </div>
            </div>
        </div>
    </div>
</div>