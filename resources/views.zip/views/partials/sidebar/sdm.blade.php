<li><span class='icon-thumbnail'><i data-feather='briefcase'></i></span><a href='#' data-page='#'>SDM<span
            class='arrow'></span></a>
    <ul class='sub-menu'>
        <li><a href='/{{ $role }}datakaryawan' data-page='datakaryawan'>Data Karyawan</a></li>
        <li><a href='/pencarianprofil' data-page='pencarianprofil'>Pencarian Profil</a></li>
    </ul>
</li>
