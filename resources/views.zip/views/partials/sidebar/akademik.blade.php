<li><span class='icon-thumbnail'><i data-feather='book'></i></span><a href='#' data-page='#'>Akademik<span
            class='arrow'></span></a>
    <ul class='sub-menu'>
        <li><a href='/{{ $role }}penilaian' data-page='penilaian'>Penilaian</a></li>
        <li><a href='/{{ $role }}presensi' data-page='presensi'>Presensi</a></li>
        <li><a href='/{{ $role }}jadwalkelas' data-page='jadwalkelas'>Jadwal Kelas</a></li>
    </ul>
</li>
