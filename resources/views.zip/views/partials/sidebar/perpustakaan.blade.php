<li><span class='icon-thumbnail'><i data-feather='book-open'></i></span><a href='#' data-page='#'>Perpustakaan<span
            class='arrow'></span></a>
    <ul class='sub-menu'>
        <li><a href='/{{ $role }}peminjamanbuku' data-page='peminjamanbuku'>Peminjaman Buku</a></li>
    </ul>
</li>
