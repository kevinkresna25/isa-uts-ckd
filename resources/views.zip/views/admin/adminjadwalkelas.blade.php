@extends('layouts.main')

@section('title', 'Jadwal Kelas')

@section('breadcrumb')
    <li class="breadcrumb-item active"><a href="/jadwalkelas">Jadwal Kelas</a></li>
@endsection

@section('card')
    @include('umum.datainfo')
@endsection

